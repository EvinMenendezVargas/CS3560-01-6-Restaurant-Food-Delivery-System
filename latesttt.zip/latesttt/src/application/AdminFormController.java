package application;

import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import java.sql.Blob.*;
import java.sql.*;
import javafx.scene.image.*;


public class AdminFormController implements Initializable {
	
    @FXML
    private Button addToMenu_btn;
    
    @FXML
    private Button clearForm_btn;

    @FXML
    private Button customers_btn;

    @FXML
    private Button drivers_btn;

    @FXML
    private TableColumn<menuItem, String> inventory_col_date;

    @FXML
    private TableColumn<menuItem, String> inventory_col_foodItemID;

    @FXML
    private TableColumn<menuItem, String> inventory_col_itemName;

    @FXML
    private TableColumn<menuItem, String> inventory_col_price;

    @FXML
    private TableColumn<menuItem, String> inventory_col_category;

    @FXML
    private AnchorPane menu_form;

    @FXML
    private TableView<menuItem> inventory_tableView;
    
    @FXML
    private TextField foodItemID_txtbox;

    @FXML
    private TextField itemName_txtbox;

    @FXML
    private Button logout_btn;
    
    @FXML
    private ImageView item_imageView;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Button menu_btn;

    @FXML
    private TextField price_txtbox;

    @FXML
    private Button removeFromMenu_btn;

    @FXML
    private ComboBox<?> category_box;

    @FXML
    private Button updateMenu_btn;
    
    @FXML
    private AnchorPane drivers_form;
    
    //Driver stuff:
    @FXML
    private Button addDriverBtn;

    @FXML
    private Button updateDriverBtn;
    
    @FXML
    private Button deleteDriverBtn;
    
    @FXML
    private Button clearDriverFormBtn;
    
    @FXML
    private TextField driverLicenseTF;
    
    @FXML
    private TextField driverNameTF;
    
    @FXML
    private ComboBox<?> carTypeCB;
    
    private String[] carTypeList = {"SUV", "SEDAN", "VAN", "HATCHBACK", "PICKUP", "MICRO", "SPORT", "COUPE"};
    
    private String[] driverStatusList = {"Available", "Unavailable"};
    
    @FXML
    private ComboBox<?> driverStatusCB;
    
    @FXML
    private TableView<driverItem> driverTableView;
    
    @FXML
    private TableColumn<driverItem, String> table_driverLicense;

    @FXML
    private TableColumn<driverItem, String> table_driverName;

    @FXML
    private TableColumn<driverItem, String> table_carType;

    @FXML
    private TableColumn<driverItem, String> table_driverStatus;

    @FXML
    private TableColumn<driverItem, String> table_driverDate;

    
    private Connection connect;
    
    private PreparedStatement prepare, retrieve;
    
    private Statement statement;
    
    private ResultSet result;
    
    private Alert alert; 
    
    private Image image;
    
    public static String path;
    
    private String[] categoryList = {"Appetizers", "Salads and Soups", "Entrees", "Sides", "Desserts", "Other"};

    

    public void switchForm(ActionEvent event) {
    	
    	if(event.getSource() == menu_btn) {
    		menu_form.setVisible(true);
    		drivers_form.setVisible(false);
    		inventoryCategoryList();
    		inventoryShowData();
    	} else if (event.getSource() == drivers_btn) {
    		menu_form.setVisible(false);
    		drivers_form.setVisible(true);
    		// customers_form.setVisible(false);
    		carTypeList();
    		driverStatusList();
    		driverShowData();
    		
    	}
    	
    }
   
    /** 
     * Establishes a connection to the database and reads the menu item into a list
     * @return A list of the menu item's data
     */
    public ObservableList<menuItem> inventoryDataList() {
    	
    	ObservableList<menuItem> listData = FXCollections.observableArrayList();
    	
    	String sql = "SELECT * FROM menu";
    	
    	connect = database.connectDB();
    	
    	try{
    		
    		prepare = connect.prepareStatement(sql);
    		result = prepare.executeQuery();
    	
    		menuItem menuItemData;
    		
    		while(result.next()) {
    			menuItemData = new menuItem(
    							result.getInt("id"),
    							result.getString("foodItemID"),					
    							result.getString("itemName"), 
    							result.getString("category"),
    							result.getDouble("price"),
    							result.getString("image"),
    							result.getDate("date"));
    			listData.add(menuItemData);
    		}
    		
    	} catch(Exception e) {e.printStackTrace();}
    	
    	return listData;
    }
    
    private ObservableList<menuItem> inventoryListData;
    /**
     * Show data in table on the GUI
     */
    public void inventoryShowData() {
    	inventoryListData = inventoryDataList();
    	
    	inventory_col_foodItemID.setCellValueFactory(new PropertyValueFactory<>("foodItemID"));
    	inventory_col_itemName.setCellValueFactory(new PropertyValueFactory<>("itemName"));
    	inventory_col_category.setCellValueFactory(new PropertyValueFactory<>("category"));
    	inventory_col_price.setCellValueFactory(new PropertyValueFactory<>("price"));
    	inventory_col_date.setCellValueFactory(new PropertyValueFactory<>("date"));
    	
    	inventory_tableView.setItems(inventoryListData);
    	
    }
    
    public ObservableList<driverItem> driverDataList() {
    	
    	ObservableList<driverItem> listData = FXCollections.observableArrayList();
    	
    	String sql = "SELECT * FROM driver";
    	
    	connect = database.connectDB();
    	
    	try{
    		
    		prepare = connect.prepareStatement(sql);
    		result = prepare.executeQuery();
    	
    		driverItem driverItemData;
    		
    		while(result.next()) {
    			driverItemData = new driverItem(
    							result.getInt("driverId"), 
    							result.getString("driverLicense"), 
    							result.getString("driverName"),
    							result.getString("carType"),
    							result.getString("driverStatus"),
    							result.getDate("date"));
    			listData.add(driverItemData);
    		}
    		
    	} catch(Exception e) {e.printStackTrace();}
    	
    	return listData;
    }
    
    private ObservableList<driverItem> driverListData;
    public void driverShowData() {
    	driverListData = driverDataList();
    	
    	table_driverLicense.setCellValueFactory(new PropertyValueFactory<>("driverLicense"));
    	table_driverName.setCellValueFactory(new PropertyValueFactory<>("driverName"));
    	table_carType.setCellValueFactory(new PropertyValueFactory<>("carType"));
    	table_driverStatus.setCellValueFactory(new PropertyValueFactory<>("driverStatus"));
    	table_driverDate.setCellValueFactory(new PropertyValueFactory<>("date"));
    	
    	driverTableView.setItems(driverListData);
    	
    }
    
    /**
     * read and add input from user into database
     */
    public void addToMenu() {
    	
    	// Check if all fields are empty
    	if (foodItemID_txtbox.getText().isEmpty() || itemName_txtbox.getText().isEmpty() 
    			|| price_txtbox.getText().isEmpty() || category_box.getSelectionModel().getSelectedItem() == null
    			) { //|| data.path == null
    		alert = new Alert(AlertType.ERROR);
    		alert.setTitle("Error Message");
    		alert.setHeaderText(null);
    		alert.setContentText("Please fill all blank fields");
    		alert.showAndWait();
    		
    	} else {
    		
    		// Check if foodItemID already exists
    		String checkItemID = "SELECT foodItemID FROM menu WHERE foodItemID = '"
    				+ foodItemID_txtbox.getText() + "'";
    		connect = database.connectDB();
    		
    		
    		try {
    			
    			statement = connect.createStatement();
    			result = statement.executeQuery(checkItemID);
    			
    			if(result.next()) {
    				alert = new Alert(AlertType.ERROR);
    	    		alert.setTitle("Error Message");
    	    		alert.setHeaderText(null);
    	    		alert.setContentText(foodItemID_txtbox.getText() + " is already taken");
    	    		alert.showAndWait();
    			} else {	
    			
    			String insertData = "INSERT INTO menu "
    					+ "(foodItemID, itemName, category, price, date) "
    					+ "VALUES(?,?,?,?,?,?)";
    			
    			prepare = connect.prepareStatement(insertData);
    			prepare.setString(1, foodItemID_txtbox.getText());
    			prepare.setString(2, itemName_txtbox.getText());
    			prepare.setString(3, (String) category_box.getSelectionModel().getSelectedItem());
    			prepare.setString(4, price_txtbox.getText());
    			
    			String path = data.path;
    			path = path.replace("\\", "\\\\");
    			prepare.setString(5, path);
    			
    			Date date = new Date();
    			java.sql.Date sqlDate = new java.sql.Date(date.getTime());
    			prepare.setString(6, String.valueOf(sqlDate));
    					
    			prepare.executeUpdate();
    			
    			/*
    			alert = new Alert(AlertType.INFORMATION);
        		alert.setTitle("Error Message");
        		alert.setHeaderText(null);
        		alert.setContentText("Successfully Added!");
        		alert.showAndWait();
        		*/
    			
    			inventoryShowData();
    			clearForm();
    			
    			}
    			
    		} catch (Exception e) {e.printStackTrace();}
    		
    	}
    	
    }
    
    public void deleteFromMenu() {
    	if (foodItemID_txtbox.getText().isEmpty() || itemName_txtbox.getText().isEmpty() 
    			|| price_txtbox.getText().isEmpty() || data.path == null || data.id == 0) {
    		
    		alert = new Alert(AlertType.ERROR);
    		alert.setTitle("Error Message");
    		alert.setHeaderText(null);
    		alert.setContentText("Please fill all blank fields");
    		alert.showAndWait();
    		
    	} else {	
    		String deleteData = "DELETE FROM menu WHERE id = " + data.id;
    		
    		try {
    			prepare = connect.prepareStatement(deleteData);
    			prepare.executeUpdate();
    			
    			inventoryShowData();
    			clearForm();
    			
    		} catch (Exception e) {e.printStackTrace();}
    	}
    }
    
    public void updateMenu() {
    	if (foodItemID_txtbox.getText().isEmpty() || itemName_txtbox.getText().isEmpty() 
    			|| price_txtbox.getText().isEmpty() || category_box.getSelectionModel().getSelectedItem() == null
    			|| data.path == null || data.id == 0) {
    		alert = new Alert(AlertType.ERROR);
    		alert.setTitle("Error Message");
    		alert.setHeaderText(null);
    		alert.setContentText("Please fill all blank fields");
    		alert.showAndWait();
    		
    	} else {
    		String path = data.path;
    		path = path.replace("\\", "\\\\");
    		String updateData = "UPDATE menu SET " + "foodItemID = '" + foodItemID_txtbox.getText()
    											+ "', itemName = '" + itemName_txtbox.getText()
    											+ "', category = '" + category_box.getSelectionModel().getSelectedItem()
    											+ "', price = '" + price_txtbox.getText()
    											+ "', image = '" + path
    											+ "', date = '" + data.date
    											+ "'WHERE id = " + data.id;
    		
    		connect = database.connectDB();
    		
    		try {
    			prepare = connect.prepareStatement(updateData);
    			prepare.executeUpdate();
    			inventoryShowData();
    			clearForm();
    			
    		} catch(Exception e) {e.printStackTrace();}
    	}
    }
    
    /**
     * Clears fields in the form
     */
    public void clearForm() {
    	foodItemID_txtbox.setText("");
    	itemName_txtbox.setText("");
    	category_box.getSelectionModel().clearSelection();
    	price_txtbox.setText("");
    	//data.path = "";
    	item_imageView.setImage(null);
    }
    
    //Portion for admining driver stuff
    public void addDriver() {
    	
    	// Check if all fields are empty
    	if (driverLicenseTF.getText().isEmpty() || driverNameTF.getText().isEmpty() 
    			|| carTypeCB.getSelectionModel().getSelectedItem() == null || driverStatusCB.getSelectionModel().getSelectedItem() == null) {
    		alert = new Alert(AlertType.ERROR);
    		alert.setTitle("Error Message");
    		alert.setHeaderText(null);
    		alert.setContentText("Please fill all blank fields");
    		alert.showAndWait();
    	} else {
    		
    		// Check if driver already exists
    		String checkLicense = "SELECT driverLicense FROM driver WHERE driverLicense = '"
    				+ driverLicenseTF.getText() + "'";
    		connect = database.connectDB();
    		
    		
    		try {
    			
    			statement = connect.createStatement();
    			result = statement.executeQuery(checkLicense);
    			
    			if(result.next()) {
    				alert = new Alert(AlertType.ERROR);
    	    		alert.setTitle("Error Message");
    	    		alert.setHeaderText(null);
    	    		alert.setContentText(driverLicenseTF.getText() + " is already taken");
    	    		alert.showAndWait();
    			} else {	
    			
    				//inserting data into the database
    			String insertData = "INSERT INTO driver "
    					+ "(driverLicense, driverName, carType, driverStatus, date) "
    					+ "VALUES(?,?,?,?,?)";
    			
    			prepare = connect.prepareStatement(insertData);
    			prepare.setString(1, driverLicenseTF.getText());
    			prepare.setString(2, driverNameTF.getText());
    			prepare.setString(3, (String) carTypeCB.getSelectionModel().getSelectedItem());
    			prepare.setString(4, (String) driverStatusCB.getSelectionModel().getSelectedItem());
    			
    			//String path = data.path;
    			//path = path.replace("\\", "\\\\");
    			//prepare.setString(5, path);
    			
    			Date date = new Date();
    			java.sql.Date sqlDate = new java.sql.Date(date.getTime());
    			prepare.setString(5, String.valueOf(sqlDate));
    					
    			prepare.executeUpdate();
    			
    			/*
    			alert = new Alert(AlertType.INFORMATION);
        		alert.setTitle("Error Message");
        		alert.setHeaderText(null);
        		alert.setContentText("Successfully Added!");
        		alert.showAndWait();
        		*/
    			
    			driverShowData();
    			clearDriverForm();
    			
    			}
    			
    		} catch (Exception e) {e.printStackTrace();}
    		
    	}
    	
    }
    
    //updates the details of a driver based on the driverId
    public void updateDriver() {
    	if (driverLicenseTF.getText().isEmpty() || driverNameTF.getText().isEmpty() 
    			|| driverStatusCB.getSelectionModel().getSelectedItem() == null || carTypeCB.getSelectionModel().getSelectedItem() == null
    			|| data.id == 0) {
    		alert = new Alert(AlertType.ERROR);
    		alert.setTitle("Error Message");
    		alert.setHeaderText(null);
    		alert.setContentText("Please fill all blank fields");
    		alert.showAndWait();
    		
    	} else {
    		//String path = data.path;
    		//path = path.replace("\\", "\\\\");
    		String updateData = "UPDATE driver SET " + "driverLicense = '" + driverLicenseTF.getText()
    											+ "', driverName = '" + driverNameTF.getText()
    											+ "', carType = '" + carTypeCB.getSelectionModel().getSelectedItem()
    											+ "', driverStatus = '" + driverStatusCB.getSelectionModel().getSelectedItem()
    											+ "', date = '" + data.date
    											+ "'WHERE driverId = " + data.id;
    		connect = database.connectDB();
    		
    		try {
    			prepare = connect.prepareStatement(updateData);
    			prepare.executeUpdate();
    			driverShowData();
    			clearDriverForm();
    			
    		} catch(Exception e) {e.printStackTrace();}
    	}
    }
    
    //deletes row from data table based on the id
    public void deleteDriver() {
    	if (driverLicenseTF.getText().isEmpty() || driverNameTF.getText().isEmpty() || data.id == 0) {
    		
    		alert = new Alert(AlertType.ERROR);
    		alert.setTitle("Error Message");
    		alert.setHeaderText(null);
    		alert.setContentText("Please fill in blank text fields");
    		alert.showAndWait();
    		
    	} else {	
    		String deleteData = "DELETE FROM driver WHERE driverId = " + data.id;
    		
    		try {
    			prepare = connect.prepareStatement(deleteData);
    			prepare.executeUpdate();
    			
    			driverShowData();
    			clearDriverForm();
    			
    		} catch (Exception e) {e.printStackTrace();}
    	}
    }
    
    //Will set all of the field to blank.
    public void clearDriverForm() {
    	driverLicenseTF.setText("");
    	driverNameTF.setText("");
    	carTypeCB.getSelectionModel().clearSelection();
    	driverStatusCB.getSelectionModel().clearSelection();
    }

   
    //Whenever the driver table is clicked on, this method will play. It will use the getters from driverItem.java to then fill in the missing fields.
    public void driverTableSelectData() {
    	driverItem driverItemData = driverTableView.getSelectionModel().getSelectedItem();
    	int num = driverTableView.getSelectionModel().getSelectedIndex();
    	
    	if ((num - 1) < -1) return;
    	
    	driverLicenseTF.setText(driverItemData.getDriverLicense());
    	driverNameTF.setText(driverItemData.getDriverName());
    	
    	data.date = String.valueOf(driverItemData.getDate());
    	data.id = driverItemData.getdriverId();
    	
    }
    
    //Whenever the inventory table is clicked on, this method will play. It will use the getters from menuItem.java to then fill in the missing fields.
    public void inventorySelectData() {
    	menuItem menuItemData = inventory_tableView.getSelectionModel().getSelectedItem();
    	int num = inventory_tableView.getSelectionModel().getSelectedIndex();
    	
    	if ((num - 1) < -1) return;
    	
    	foodItemID_txtbox.setText(menuItemData.getFoodItemID());
    	itemName_txtbox.setText(menuItemData.getItemName());
    	price_txtbox.setText(String.valueOf(menuItemData.getPrice()));
    	
    	data.path = "File:" + menuItemData.getImage();
    	data.date = String.valueOf(menuItemData.getDate());
    	data.id = menuItemData.getID();
    	image = new Image(data.path, 144, 150, false, true);
    	item_imageView.setImage(image);
    	
    }
    
    public void inventoryImportBtn() {
    	
    	FileChooser openFile = new FileChooser();
    	openFile.getExtensionFilters().add(new ExtensionFilter("Open Image File", "*png", "*jpg"));
    	
    	File file = openFile.showOpenDialog(main_form.getScene().getWindow());
    	
    	if(file != null) {
    		data.path = file.getAbsolutePath();
    		image = new Image(file.toURI().toString(), 144, 150, false, true);
    		
    		item_imageView.setImage(image);
    		
    	}
    }
    
    @FXML
    public void goLogout() {
    	
    	try {
    		logout_btn.getScene().getWindow().hide();
        	
        	Parent root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        	
        	Stage stage = new Stage();
        	Scene scene = new Scene(root);
        	
        	stage.setTitle("Restaurant Food Management System");
        	stage.setScene(scene);
        	stage.show();
        	
		} catch(Exception e) {
			e.printStackTrace();
		}
    }
    
    // Fills ComboBox with category types
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public void inventoryCategoryList() {
    	
    	List<String> categoryArray = new ArrayList<>();
    	
    	for (String data: categoryList) {
    		categoryArray.add(data);
    	}
    	
    	ObservableList listData = FXCollections.observableArrayList(categoryArray);
    	category_box.setItems(listData);
    }
    
    //setting up the car type combobox
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public void carTypeList() {
    	
    	List<String> categoryArray = new ArrayList<>();
    	
    	for (String data: carTypeList) {
    		categoryArray.add(data);
    	}
    	
    	ObservableList listData = FXCollections.observableArrayList(categoryArray);
    	carTypeCB.setItems(listData);
    }
    
    //setting up the status combobox
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public void driverStatusList() {
    	
    	List<String> categoryArray = new ArrayList<>();
    	
    	for (String data: driverStatusList) {
    		categoryArray.add(data);
    	}
    	
    	ObservableList listData = FXCollections.observableArrayList(categoryArray);
    	driverStatusCB.setItems(listData);
    }
    
    // initializing the tables and rows and lists
	@Override
	public void initialize(URL location, ResourceBundle resource) {
		inventoryCategoryList();
		inventoryShowData();
		carTypeList();
		driverStatusList();
		driverShowData();
	}
	
}