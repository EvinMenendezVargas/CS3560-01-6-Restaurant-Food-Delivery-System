package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.util.Date;
import javafx.fxml.Initializable;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;


public class cardController implements Initializable {
	
	@FXML
    private Button add_btn;
	
	private SpinnerValueFactory<Integer> spin;

    @FXML
    private AnchorPane card_form;

    @FXML
    private Label itemName;

    @FXML
    private ImageView item_imageView;

    @FXML
    private Label price;

    @FXML
    private Spinner<Integer> spinner;
    
    private menuItem menuItem;
    
    private Image image;
    
    private String foodItemID;
    private String item_image;
    private String item_date;
    
    private int qty;
    
    private double totalPrice;
    
    private double pr;
    
    private Connection connect;
    
    private PreparedStatement prepare;
    
    private ResultSet result;
    
    private Alert alert;
    
    public void setData(menuItem menuItem) {
    	this.menuItem = menuItem;
    	
    	item_image = menuItem.getImage();
    	item_date = String.valueOf(menuItem.getDate());
    	foodItemID = menuItem.getFoodItemID();
    	itemName.setText(menuItem.getItemName());
    	price.setText("$"+String.valueOf(menuItem.getPrice()));
    	String path = "File: " + menuItem.getImage();
    	image = new Image(menuItem.getImage(), 200, 113, false, true);
    	item_imageView.setImage(image);
    	pr = menuItem.getPrice();
    }
   
    public void setQuantity() {
    	spin = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100, 0);
    	spinner.setValueFactory(spin);
    }
    
   
    public void add_btn() {
    	
    	CustomerFormController custForm = new CustomerFormController();
    	custForm.customerID();
    	
    	qty = spinner.getValue();
    	
    	if (qty == 0) {
    		alert = new Alert(AlertType.ERROR);
    		alert.setTitle("Error Message");
    		alert.setHeaderText(null);
    		alert.setContentText("Please add a valid amount.");
    		
    	} else {
    		String insertData = "INSERT INTO neworder " + "(customer_id, foodItemID, itemName, qty, price, date) "
    							+ "VALUES(?,?,?,?,?,?)";
    		connect = database.connectDB();
    		try {
    			
    			prepare = connect.prepareStatement(insertData);
    			prepare.setString(1, String.valueOf(data.cID));
    			prepare.setString(2, foodItemID);
    			prepare.setString(3, itemName.getText());
    			prepare.setString(4, String.valueOf(qty));
    			
    			totalPrice = (qty * pr);
    			prepare.setString(5, String.valueOf(totalPrice));
    			
    			Date date = new Date();
    			java.sql.Date sqlDate = new java.sql.Date(date.getTime());
    			prepare.setString(6, String.valueOf(sqlDate));
    			
    			prepare.executeUpdate();
    			
    			custForm.getTotal();
    			
    			item_image = item_image.replace("\\", "\\\\");
    		} catch (Exception e) {e.printStackTrace();}
    	}
    }
    

	public void initialize(URL location, ResourceBundle resources) {
		setQuantity();
	}
}