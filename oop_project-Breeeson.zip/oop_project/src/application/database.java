package application;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Class to get connection to database. To get connection:
 * "jdbc:mysql://localhost/[name of database], username, password
 * 
 *
 */
public class database {

	public static Connection connectDB() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurant", "root", "BT@4537&2966"); //
			
			return connect;
		
		} catch (Exception e) {e.printStackTrace();}
		return null;
	}
	
}
