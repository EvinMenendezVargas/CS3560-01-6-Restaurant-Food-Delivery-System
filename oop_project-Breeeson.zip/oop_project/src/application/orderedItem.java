package application;

import java.sql.Date;

public class orderedItem {
	
	private String itemName;
	private Double itemPrice;
	private Integer itemQuantity;
	
	

	
	public orderedItem(String itemName, Double itemPrice, Integer itemQuantity) {
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.itemQuantity = itemQuantity;
	}

	public String getItemName() {
		return itemName;
	}

	public Double getItemPrice() {
		return itemPrice;
	}

	public Integer getItemQuantity() {
		return itemQuantity;
	}
}