package application;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.Button;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.sql.Blob.*;
import java.sql.*;
import javafx.scene.image.*;


public class CustomerFormController implements Initializable {
	
    @FXML
    private BorderPane border_Pane;
    
	@FXML
    private TableColumn<menuItem, String> col_menuItemName;

    @FXML
    private TableColumn<menuItem, String> col_price;

    @FXML
    private TableColumn<menuItem, String> col_qty;

    @FXML
    private Button logout_btn;
    
    @FXML
    private AnchorPane orderPane;

    @FXML
    private Button order_btn;
    
    @FXML
    private Button deliveryStatus_btn;

    @FXML
    private Button checkOut_btn;
    
    @FXML
    private Button completeOrder_btn;

    @FXML
    private AnchorPane payment_form;

    @FXML
    private AnchorPane order_form;

    @FXML
    private GridPane menu_gridPane;

    @FXML
    private ScrollPane menu_scrollPane;

    @FXML
    private TableView<menuItem> menu_tableView;

    @FXML
    private Button placeOrder_btn;

    @FXML
    private Label menu_total;
    
 // checkout 
    @FXML
    private TextField securityCode_txtbox;
    
    @FXML
    private TextField cardHolderName_txtbox;
    
    @FXML
    private TextField cardNumber_txtbox;
    
    @FXML
    private TextField checkoutAddress_txtbox;

    @FXML
    private TextField checkoutName_txtbox;

    @FXML
    private TextField checkoutPhoneNumber_txtbox;

    @FXML
    private TextField expiryDate_txtbox;
    
    @FXML
    private TextField postalCode_txtbox;

    
    private Connection connect;
    
    private PreparedStatement prepare, retrieve;
    
    private Statement statement;
    
    private ResultSet result;
    
    private Alert alert; 
    
    private Image image;

    private ObservableList<menuItem> cardListData = FXCollections.observableArrayList();
    
    public void switchForm(ActionEvent event) {
    	
    	if(event.getSource() == order_btn) {
    		order_form.setVisible(true);
    		payment_form.setVisible(false);
    		displayCard();
    		getOrder();
    		displayTotal();
    		showOrderData();
    		// deliveryStatus_form.setVisible(false);
    		
    	} else if (event.getSource() == checkOut_btn){
    		order_form.setVisible(false);
    		payment_form.setVisible(true);
    		
        	//deliveryStatus_form.setVisible(true); 

    	}
    
    }
    
    /**
     * Retrieves data from menu table in database
     * @return List of item data from existing menu items
     */
    public ObservableList<menuItem> menuGetData() {
    	// Connect to database
    	String sql = "SELECT * FROM menu";
    	ObservableList<menuItem> listData = FXCollections.observableArrayList();
    	connect = database.connectDB();
    	
    	try {
    		prepare = connect.prepareStatement(sql);
    		result = prepare.executeQuery();
    		
    		menuItem item;
    		
    		while (result.next()) {
    			item = new menuItem(result.getInt("id"), result.getString("foodItemID"), 
    					result.getString("itemName"), result.getString("category"), 
    					result.getDouble("price"), 
    					result.getString("image"), result.getDate("date"));
    		
    			listData.add(item);
    		}
    		
    	} catch(Exception e) {e.printStackTrace();}
    	
    	return listData;
    }
    
    /**
     * Displays each card in the grid pane
     */
    public void displayCard() {
    	cardListData.clear();
    	cardListData.addAll(menuGetData());
    	
    	int row = 0; int col = 0;
    	menu_gridPane.getChildren().clear();
    	menu_gridPane.getRowConstraints().clear();
    	menu_gridPane.getColumnConstraints().clear();
    	for (int i = 0; i < cardListData.size(); i++) {
    		try {
				FXMLLoader load = new FXMLLoader();
				load.setLocation(getClass().getResource("Card.fxml"));
				AnchorPane pane = load.load();
				cardController cardControl = load.getController();
				cardControl.setData(cardListData.get(i));

				if (col == 2) {
					col = 0;
					row += 1;
				}
				
				menu_gridPane.add(pane, col++, row);
				GridPane.setMargin(pane, new Insets(10));
				
			} catch (Exception e) {e.printStackTrace();}
    	}
    }

    /**
     * Accesses the neworder database to get the items ordered
     * @return A list of ordered items
     */
    public ObservableList<menuItem> getOrder() {
    	ObservableList<menuItem> listData = FXCollections.observableArrayList();
    	
    	String sql = "SELECT * FROM neworder";
    	
    	connect = database.connectDB();
    	
    	try {
    		prepare = connect.prepareStatement(sql);
    		result = prepare.executeQuery();
    		menuItem item;
    		while (result.next()) {
    			item = new menuItem(result.getInt("orderNo"),
    					result.getString("foodItemID"),
    					result.getString("itemName"),
    					result.getInt("qty"),
    					result.getDouble("price"),
    					result.getDate("date"));
    			listData.add(item);
    			
    		}
    	} catch (Exception e) {e.printStackTrace();}
    	
    	return listData;
    }
   
    
    private double totalPrice;
    public void getTotal() {
    	customerID();
    	String total = "SELECT SUM(price) FROM neworder WHERE customer_id = " + cID; 
    	connect = database.connectDB();
    	
    	try {
    		prepare = connect.prepareStatement(total);
    		result = prepare.executeQuery();
    		
    		if (result.next()) {
    			totalPrice = result.getDouble("SUM(price)");
    		}
    		
    		
    		    		
    	} catch(Exception e) {e.printStackTrace();}
    }
    
    public void displayTotal() {
    	getTotal();
    	menu_total.setText("$" + totalPrice);
    }
    
    
    
    private ObservableList<menuItem> menuListData;
    public void showOrderData() {
    	menuListData = getOrder();
    	
    	col_menuItemName.setCellValueFactory(new PropertyValueFactory<>("itemName"));
    	col_qty.setCellValueFactory(new PropertyValueFactory<>("qty"));
    	col_price.setCellValueFactory(new PropertyValueFactory<>("price"));
    	menu_tableView.setItems(menuListData);
    }
    
   
    
    
    private int cID;
    public void customerID() {
    	String sql = "SELECT MAX(customer_id) FROM neworder";
    	connect = database.connectDB();
    	
    	try {
    		prepare = connect.prepareStatement(sql);
    		result = prepare.executeQuery();
    		
    		if (result.next()) {
    			cID = result.getInt("MAX(customer_id)");
    			
    		}
    		
    		String checkCID = "SELECT MAX(customer_id) FROM checkoutdetail";
    		prepare = connect.prepareStatement(checkCID);
    		result = prepare.executeQuery();
    		
    		
    		int checkID = 0;
    		if (result.next()) {
    			checkID = result.getInt("MAX(customer_id)");
    		}
    		
    		if(cID == 0) {
    			cID+=1;
    			
    		} else if (cID == checkID) {
    			cID+=1;
    		}
    		
    		data.cID = cID;
    		
    	} catch (Exception e) {e.printStackTrace();}
    }
	
    @FXML
    public void goLogout() {
    	
    	try {
    		logout_btn.getScene().getWindow().hide();
        	
        	Parent root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        	
        	Stage stage = new Stage();
        	Scene scene = new Scene(root);
        	
        	stage.setTitle("Restaurant Food Management System");
        	stage.setScene(scene);
        	stage.show();
        	
		} catch(Exception e) {
			e.printStackTrace();
		}
    }
    
    
    // click on place order button takes you to the checkout payment screen
   
    @FXML
    public void goPlaceOrder() {
    	try {
    		placeOrder_btn.getScene().getWindow().hide();
        	
        	FXMLLoader fxmlLoader = new FXMLLoader();
        	fxmlLoader.setLocation(getClass().getResource("CheckoutPaymentScreen.fxml"));
        	
        	Stage stage = new Stage();
        	Scene scene = new Scene(fxmlLoader.load(), 1100, 600);
        	
        	stage.setTitle("Restaurant Food Management System");
        	stage.setScene(scene);
        	stage.show();
        	
		} catch(Exception e) {
			e.printStackTrace();
		}
    		
    }
  
    /*
    public void placeOrderBtn() {
    	if (totalPrice == 0) {
    		alert = new Alert(AlertType.ERROR);
    		alert.setTitle("Error Message");
    		alert.setHeaderText(null);
    		alert.setContentText("Please add to order first.");
    		alert.showAndWait();
    	} else {
    		getTotal();
    		
    		String setOrderID = "INSERT checkoutdetail(orderNo) SELECT orderNo FROM newOrder";
    		String insertPay = "INSERT INTO checkoutdetail (customer_id, total) "
    				+ "VALUES(customer_id, total)";
    		
    		
    		connect = database.connectDB();
    		
    		try {
    			customerID();
    			getTotal();
    			
    			prepare = connect.prepareStatement(setOrderID);
    			prepare.executeUpdate();
    			
    			prepare = connect.prepareStatement(insertPay);
    			prepare.setString(1, String.valueOf(cID));
    			prepare.setString(2, String.valueOf(totalPrice));
    			prepare.executeUpdate();
    			showOrderData();
    			
    			alert = new Alert(AlertType.INFORMATION);
        		alert.setTitle("Information Message");
        		alert.setHeaderText(null);
        		alert.setContentText("Please proceed to Check Out to complete your order.");
        		alert.showAndWait();
    			
    			
    			
    			
    		} catch(Exception e) {e.printStackTrace();}
    	}
    }
    */
    
    public void placeOrderBtn() {
    	alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Information Message");
		alert.setHeaderText(null);
		alert.setContentText("Please proceed to Check Out to complete your order.");
		alert.showAndWait();
    }
    
    // Everything for the checkout details page
    @FXML
    public void completeOrder() {
    	
   
    	
    	if (securityCode_txtbox.getText().isEmpty() || cardHolderName_txtbox.getText().isEmpty()
				|| cardNumber_txtbox.getText().isEmpty() || checkoutAddress_txtbox.getText().isEmpty()
				|| checkoutName_txtbox.getText().isEmpty() || checkoutPhoneNumber_txtbox.getText().isEmpty() 
				|| expiryDate_txtbox.getText().isEmpty() || postalCode_txtbox.getText().isEmpty()) {
    		
			alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error Message");
			alert.setHeaderText(null);
			alert.setContentText("Please fill all blank fields");
			alert.showAndWait();
			
		} else {
			// Store into database values 
			String inputCheckoutData = "INSERT INTO CheckoutDetail (customer_name, customer_address, customer_phoneNumber, cardHolder_name, cardNumber, cardSecurityCode, zipcode) "
					+ "VALUES(?,?,?,?,?,?,?)";
			
			//String inputOrderData = "INSERT INTO newOrder (ItemName, quantity, total, date, orderStatus) "
					//+ "VALUES(?,?,?,?,Cooking)";
			
			connect = database.connectDB();
			
			try {
					
				// Success: Add information to data base
				// int corresponds to a value in input
				prepare = connect.prepareStatement(inputCheckoutData);
				prepare.setString(1, checkoutName_txtbox.getText());
				prepare.setString(2, checkoutAddress_txtbox.getText());
				prepare.setString(3, checkoutPhoneNumber_txtbox.getText());
				prepare.setString(4, cardHolderName_txtbox.getText());
				prepare.setString(5, cardNumber_txtbox.getText());
				prepare.setString(6, securityCode_txtbox.getText());
				prepare.setString(7, postalCode_txtbox.getText());
				
				//prepare.executeQuery();
				prepare.executeUpdate();
				
			//	prepare = connect.prepareStatement(inputCheckoutData);
				//prepare.setString(1, checkoutName_txtbox.getText());
				//prepare.setString(2, checkoutAddress_txtbox.getText());
				//prepare.setString(3, checkoutPhoneNumber_txtbox.getText());
				//prepare.setString(4, cardHolderName_txtbox.getText());
				
				alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Information Message");
				alert.setHeaderText(null);
				alert.setContentText("Your order has been successfully placed!");
				alert.showAndWait();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
    }
    
    
    
    
	@Override
	public void initialize(URL location, ResourceBundle resource) {
		displayCard();
		getOrder();
		displayTotal();
		showOrderData();
	}

	
}