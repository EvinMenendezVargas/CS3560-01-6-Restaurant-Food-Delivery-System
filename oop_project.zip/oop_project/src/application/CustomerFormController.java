package application;

import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import java.util.ResourceBundle;
import javafx.fxml.Initializable;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;

import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.sql.Blob.*;
import java.sql.*;
import javafx.scene.image.*;


public class CustomerFormController implements Initializable {
	
	@FXML
    private TableColumn<?, ?> col_menuItemName;

    @FXML
    private TableColumn<?, ?> col_price;

    @FXML
    private TableColumn<?, ?> col_qty;

    @FXML
    private Button logout_btn;
    
    @FXML
    private AnchorPane menuForm;

    @FXML
    private GridPane menu_gridPane;

    @FXML
    private ScrollPane menu_scrollPane;

    @FXML
    private TableView<?> menu_tableView;

    @FXML
    private Button pay_btn;

    @FXML
    private Label total;

    
    private Connection connect;
    
    private PreparedStatement prepare, retrieve;
    
    private Statement statement;
    
    private ResultSet result;
    
    private Alert alert; 
    
    private Image image;




    @FXML
    public void goLogout() {
    	
    	try {
    		logout_btn.getScene().getWindow().hide();
        	
        	Parent root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        	
        	Stage stage = new Stage();
        	Scene scene = new Scene(root);
        	
        	stage.setTitle("Restaurant Food Management System");
        	stage.setScene(scene);
        	stage.show();
        	
		} catch(Exception e) {
			e.printStackTrace();
		}
    }
    
	@Override
	public void initialize(URL location, ResourceBundle resource) {
		
	}

	
}