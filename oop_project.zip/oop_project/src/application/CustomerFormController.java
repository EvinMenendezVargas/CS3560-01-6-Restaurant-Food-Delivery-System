package application;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;

import javafx.scene.control.Button;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.sql.Blob.*;
import java.sql.*;
import javafx.scene.image.*;


public class CustomerFormController implements Initializable {
	
	@FXML
    private TableColumn<?, ?> col_menuItemName;

    @FXML
    private TableColumn<?, ?> col_price;

    @FXML
    private TableColumn<?, ?> col_qty;

    @FXML
    private Button logout_btn;
    
    @FXML
    private AnchorPane orderPane;

    @FXML
    private Button order_btn;
    
    @FXML
    private Button deliveryStatus_btn;


    @FXML
    private AnchorPane order_form;

    @FXML
    private GridPane menu_gridPane;

    @FXML
    private ScrollPane menu_scrollPane;

    @FXML
    private TableView<?> menu_tableView;

    @FXML
    private Button placeOrder_btn;

    @FXML
    private Label total;

    
    private Connection connect;
    
    private PreparedStatement prepare, retrieve;
    
    private Statement statement;
    
    private ResultSet result;
    
    private Alert alert; 
    
    private Image image;

    private ObservableList<menuItem> cardListData = FXCollections.observableArrayList();
    
    public void switchForm(ActionEvent event) {
    	
    	if(event.getSource() == order_btn) {
    		order_form.setVisible(true);
    		displayCard();
    		// deliveryStatus_form.setVisible(false); 
    		
    	} else if (event.getSource() == deliveryStatus_btn) {
    		order_form.setVisible(false);
    		// deliveryStatus_form.setVisible(true); 
    	}	
    
    }
    
    public ObservableList<menuItem> menuGetData() {
    	// Connect to database
    	String sql = "SELECT * FROM menu";
    	ObservableList<menuItem> listData = FXCollections.observableArrayList();
    	connect = database.connectDB();
    	
    	try {
    		prepare = connect.prepareStatement(sql);
    		result = prepare.executeQuery();
    		
    		menuItem item;
    		
    		while (result.next()) {
    			item = new menuItem(result.getInt("id"), result.getString("foodItemID"), 
    					result.getString("itemName"), result.getDouble("price"), result.getString("image"));
    		
    			listData.add(item);
    		}
    		
    	} catch(Exception e) {e.printStackTrace();}
    	
    	return listData;
    }

    public void displayCard() {
    	cardListData.clear();
    	cardListData.addAll(menuGetData());
    	
    	int row = 0; int col = 0;
    	menu_gridPane.getChildren().clear();
    	menu_gridPane.getRowConstraints().clear();
    	menu_gridPane.getColumnConstraints().clear();
    	for (int i = 0; i < cardListData.size(); i++) {
    		try {
				FXMLLoader load = new FXMLLoader();
				load.setLocation(getClass().getResource("Card.fxml"));
				AnchorPane pane = load.load();
				cardController cardControl = load.getController();
				cardControl.setData(cardListData.get(i));

				if (col == 2) {
					col = 0;
					row += 1;
				}
				
				menu_gridPane.add(pane, col++, row);
				GridPane.setMargin(pane, new Insets(10));
				
			} catch (Exception e) {e.printStackTrace();}
    	}
    }

    @FXML
    public void goLogout() {
    	
    	try {
    		logout_btn.getScene().getWindow().hide();
        	
        	Parent root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
        	
        	Stage stage = new Stage();
        	Scene scene = new Scene(root);
        	
        	stage.setTitle("Restaurant Food Management System");
        	stage.setScene(scene);
        	stage.show();
        	
		} catch(Exception e) {
			e.printStackTrace();
		}
    }
    
    
    // click on place order button takes you to the checkout payment screen
    /*
    @FXML
    public void goPlaceOrder() {
    	try {
    		logout_btn.getScene().getWindow().hide();
        	
        	Parent root = FXMLLoader.load(getClass().getResource("CheckOutPaymentScreen.fxml"));
        	
        	Stage stage = new Stage();
        	Scene scene = new Scene(root);
        	
        	stage.setTitle("Restaurant Food Management System");
        	stage.setScene(scene);
        	stage.show();
        	
		} catch(Exception e) {
			e.printStackTrace();
		}
    		
    }
    */
    
    
	@Override
	public void initialize(URL location, ResourceBundle resource) {
		displayCard();
	}

	
}