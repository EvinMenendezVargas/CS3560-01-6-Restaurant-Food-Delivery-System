package application;

import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import java.sql.Blob.*;
import java.sql.*;
import javafx.scene.image.*;


public class adminFormController implements Initializable {
	
    @FXML
    private Button addToMenu_btn;

    @FXML
    private Button customers_btn;

    @FXML
    private Button drivers_btn;

    @FXML
    private TableColumn<menuItem, String> inventory_col_date;

    @FXML
    private TableColumn<menuItem, String> inventory_col_foodItemID;

    @FXML
    private TableColumn<menuItem, String> inventory_col_itemName;

    @FXML
    private TableColumn<menuItem, String> inventory_col_price;

    @FXML
    private TableColumn<menuItem, String> inventory_col_category;

    @FXML
    private AnchorPane inventory_form;

    @FXML
    private TableView<menuItem> inventory_tableView;

    @FXML
    private TextField itemName_txtbox;

    @FXML
    private Button logout_btn;
    
    @FXML
    private ImageView item_imageView;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Button menu_btn;

    @FXML
    private TextField price_txtbox;

    @FXML
    private Button removeFromMenu_btn;

    @FXML
    private ComboBox<?> category_box;

    @FXML
    private Button updateMenu_btn;

    private Connection connect;
    
    private PreparedStatement prepare, retrieve;
    
    private Statement statement;
    
    private ResultSet result;
    
    private Alert alert; 
    
    private Image image;
    
    public static String path;
    
    private String[] categoryList = {"Appetizers", "Salads and Soups", "Entrees", "Sides", "Desserts", "Other"};

    private ObservableList<menuItem> inventoryListData;
   
    /** 
     * Establishes a connection to the database and reads the menu item into a list
     * @return A list of the menu item's data
     */
    public ObservableList<menuItem> inventoryDataList() {
    	
    	ObservableList<menuItem> listData = FXCollections.observableArrayList();
    	
    	String sql = "SELECT * FROM menu";
    	
    	connect = database.connectDB();
    	
    	try{
    		
    		prepare = connect.prepareStatement(sql);
    		result = prepare.executeQuery();
    	
    		menuItem menuItemData;
    		
    		while(result.next()) {
    			menuItemData = new menuItem(
    							result.getInt("foodItemID"),					
    							result.getString("itemName"), 
    							result.getString("category"),
    							result.getDouble("price"),
    							result.getString("image"),
    							result.getDate("date"));
    			listData.add(menuItemData);
    		}
    		
    	} catch(Exception e) {e.printStackTrace();}
    	return listData;
    }
    
    
    /**
     * Show data in table on the GUI
     */
    public void inventoryShowData() {
    	inventoryListData = inventoryDataList();
    	
    	inventory_col_foodItemID.setCellValueFactory(new PropertyValueFactory<>("foodItemID"));
    	inventory_col_itemName.setCellValueFactory(new PropertyValueFactory<>("itemName"));
    	inventory_col_category.setCellValueFactory(new PropertyValueFactory<>("category"));
    	inventory_col_price.setCellValueFactory(new PropertyValueFactory<>("price"));
    	inventory_col_date.setCellValueFactory(new PropertyValueFactory<>("date"));
    	
    	inventory_tableView.setItems(inventoryListData);
    	
    }
    
    public void addToMenu() {
    	
    	// Check if all fields are empty
    	if (itemName_txtbox.getText().isEmpty() || price_txtbox.getText().isEmpty()
    			|| category_box.getSelectionModel().getSelectedItem() == null
    			|| data.path == null) {
    		alert = new Alert(AlertType.ERROR);
    		alert.setTitle("Error Message");
    		alert.setHeaderText(null);
    		alert.setContentText("Please fill all blank fields");
    		alert.showAndWait();
    		
    	} else {
    		
    		connect = database.connectDB();
    		
    		try {
    			String insertData = "INSERT INTO menu "
    					+ "(itemName, category, price, image, date) "
    					+ "VALUES(?,?,?,?,?)";
    			
    			prepare = connect.prepareStatement(insertData);
    			prepare.setString(1, itemName_txtbox.getText());
    			prepare.setString(2, (String) category_box.getSelectionModel().getSelectedItem());
    			prepare.setDouble(3, Double.parseDouble(price_txtbox.getText()));
    			
    			String path = data.path;
    			path = path.replace("\\", "\\\\");
    			prepare.setString(4, path);
    			
    			Date date = new Date();
    			java.sql.Date sqlDate = new java.sql.Date(date.getTime());
    			prepare.setString(5, String.valueOf(sqlDate));
    					
    			prepare.executeUpdate();
    			
    			alert = new Alert(AlertType.INFORMATION);
        		alert.setTitle("Error Message");
        		alert.setHeaderText(null);
        		alert.setContentText("Successfully Added!");
        		alert.showAndWait();
    			
    			inventoryShowData();
    			
    		} catch (Exception e) {e.printStackTrace();}
    		
    	}
    	
    }
    
    /*
    public void adminAddToMenu() {
		
		if (itemName_txtbox.getText().isEmpty() || price_txtbox.getText().isEmpty()) {
			alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error Message");
			alert.setHeaderText(null);
			alert.setContentText("Please fill all blank fields");
			alert.showAndWait();
			
		} else {
			// Store into database values 
			String addItem = "INSERT INTO menu (itemName, category, price, date) "
					+ "VALUES(?,?,?,?,?)";
			connect = database.connectDB();
			
			try {
				prepare = connect.prepareStatement(addItem);
				prepare.setString(1, itemName_txtbox.getText()); // name
				prepare.setString(2, price_txtbox.getText()); // price
				prepare.setString(3, "FOOD YUM"); // type
				Date date = new Date(0);
				java.sql.Date sqlDate = new java.sql.Date(date.getTime());
				prepare.setString(4, String.valueOf(sqlDate)); // date
				//String imgFileName = "C:\\Users\\Bryson\\Downloads\\" + imgFileNameTxtField.getText();
				//InputStream imgFile = new FileInputStream(imgFileName);
				//prepare.setBlob(5, imgFile); // picture
				prepare.executeUpdate(); // might make this the update button
				
				
				
				
				//Image showAddedImage = new Image(getClass().getResourceAsStream("download.jpg"));
				Image showAddedImage = new Image(getClass().getResourceAsStream("download.jpg"));
				fdItemImgView.setImage(showAddedImage);
				
				
			} catch (Exception e) {
				e.printStackTrace();
				}
		}
	}
	*/
    
    public void inventoryImportBtn() {
    	
    	FileChooser openFile = new FileChooser();
    	openFile.getExtensionFilters().add(new ExtensionFilter("Open Image File", "*png", "*jpg"));
    	
    	File file = openFile.showOpenDialog(main_form.getScene().getWindow());
    	
    	if(file != null) {
    		data.path = file.getAbsolutePath();
    		image = new Image(file.toURI().toString(), 144, 150, false, true);
    		
    		item_imageView.setImage(image);
    		
    	}
    }
    
    @FXML
    public void goLogout() {
    	
    	try {
    		logout_btn.getScene().getWindow().hide();
        	
        	Parent root = FXMLLoader.load(getClass().getResource("Scene1Controller.fxml"));
        	
        	Stage stage = new Stage();
        	Scene scene = new Scene(root);
        	
        	stage.setTitle("Restaurant Food Management System");
        	stage.setScene(scene);
        	stage.show();
        	
		} catch(Exception e) {
			e.printStackTrace();
		}
    }
    
    // Fills ComboBox with category types
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public void inventoryCategoryList() {
    	
    	List<String> categoryArray = new ArrayList<>();
    	
    	for (String data: categoryList) {
    		categoryArray.add(data);
    	}
    	
    	ObservableList listData = FXCollections.observableArrayList(categoryArray);
    	category_box.setItems(listData);
    }
    
	@Override
	public void initialize(URL location, ResourceBundle resource) {
		inventoryCategoryList();
		inventoryShowData();
	}
	
}