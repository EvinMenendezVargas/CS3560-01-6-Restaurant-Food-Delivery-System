package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


public class adminFormController implements Initializable {
	
    @FXML
    private Button addToMenu_btn;

    @FXML
    private Button customers_btn;

    @FXML
    private Button drivers_btn;

    @FXML
    private TableColumn<menuItem, String> inventory_col_date;

    @FXML
    private TableColumn<menuItem, String> inventory_col_foodItemID;

    @FXML
    private TableColumn<menuItem, String> inventory_col_itemName;

    @FXML
    private TableColumn<menuItem, String> inventory_col_price;

    @FXML
    private TableColumn<menuItem, String> inventory_col_category;

    @FXML
    private AnchorPane inventory_form;

    @FXML
    private TableView<menuItem> inventory_tableView;

    @FXML
    private TextField itemName_txtbox;

    @FXML
    private Button logout_btn;
    
    @FXML
    private ImageView item_imageView;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Button menu_btn;

    @FXML
    private TextField price_txtbox;

    @FXML
    private Button removeFromMenu_btn;

    @FXML
    private ComboBox<?> category_box;

    @FXML
    private Button updateMenu_btn;

    private Connection connect;
    
    private PreparedStatement prepare, retrieve;
    
    private Statement statement;
    
    private ResultSet result;
    
    private String[] categoryList = {"Appetizers", "Salads and Soups", "Entrees", "Sides", "Desserts", "Other"};

    private ObservableList<menuItem> inventoryListData;
   
    /** 
     * Establishes a connection to the database and reads the menu item into a list
     * @return A list of the menu item's data
     */
    public ObservableList<menuItem> inventoryDataList() {
    	
    	ObservableList<menuItem> listData = FXCollections.observableArrayList();
    	
    	String sql = "SELECT * FROM menu";
    	
    	connect = database.connectDB();
    	
    	try{
    	
    		prepare = connect.prepareStatement(sql);
    		result = prepare.executeQuery();
    		
    		menuItem menuItemData;
    		
    		while(result.next()) {
    			menuItemData = new menuItem(
    							result.getInt("id"), 									
    							result.getString("itemName"), 
    							result.getString("category"),
    							result.getDouble("price"),
    							result.getString("image"),
    							result.getDate("date"));
    			listData.add(menuItemData);
    		}
    		
    	} catch(Exception e) {e.printStackTrace();}
    	return listData;
    }
    
    
    /**
     * Show data in table on the GUI
     */
    public void inventoryShowData() {
    	inventoryListData = inventoryDataList();
    	
    	inventory_col_foodItemID.setCellValueFactory(new PropertyValueFactory<>("id"));
    	inventory_col_itemName.setCellValueFactory(new PropertyValueFactory<>("itemName"));
    	inventory_col_category.setCellValueFactory(new PropertyValueFactory<>("type"));
    	inventory_col_price.setCellValueFactory(new PropertyValueFactory<>("price"));
    	inventory_col_date.setCellValueFactory(new PropertyValueFactory<>("date"));
    	
    	inventory_tableView.setItems(inventoryListData);
    	
    }
    
    @FXML
    public void goLogout() {
    	
    	try {
    		logout_btn.getScene().getWindow().hide();
        	
        	Parent root = FXMLLoader.load(getClass().getResource("Scene1Controller.fxml"));
        	
        	Stage stage = new Stage();
        	Scene scene = new Scene(root);
        	
        	stage.setTitle("Restaurant Food Management System");
        	stage.setScene(scene);
        	stage.show();
        	
		} catch(Exception e) {
			e.printStackTrace();
		}
    }
    
    // Fills ComboBox with category types
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public void inventoryCategoryList() {
    	
    	List<String> categoryArray = new ArrayList<>();
    	
    	for (String data: categoryList) {
    		categoryArray.add(data);
    	}
    	
    	ObservableList listData = FXCollections.observableArrayList(categoryArray);
    	category_box.setItems(listData);
    }
    
	@Override
	public void initialize(URL location, ResourceBundle resource) {
		inventoryCategoryList();
		inventoryShowData();
	}
	
}