package application;
import java.sql.Connection;

public class database {

	public static Connection connectDB() {
		try {
			
		} catch (Exception e) {e.printStackTrace();}
	}
	
}
