package application;

import java.sql.Date;

public class menuItem {
	

	private Integer id;
	private String foodItemID;
	private String itemName;
	private String category;
	private Double price;
	private String image;
	private Date date;
	

	
	public menuItem(Integer id, String foodItemID, String itemName, String category, Double price, 
			String image, Date date) {
		this.id = id;
		this.foodItemID = foodItemID;
		this.itemName = itemName;
		this.category = category;
		this.price = price;
		this.image = image;
		this.date = date;
	}
	
	public Integer getID() {
	
		return id;
	}
	
	public String getFoodItemID() {
		
		return foodItemID;
	}


	
	public String getItemName() {
		return itemName;
	}
	
	public String getCategory() {
		return category;
	}
	
	public Double getPrice() {
		return price;
	}
	
	public String getImage() {
		return image;
	}
	
	public Date getDate() {
		return date;
	}

}