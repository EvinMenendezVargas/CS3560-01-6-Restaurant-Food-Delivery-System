package application;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class menuItem {
	

	private Integer foodItemID;
	private String itemName;
	private String category;
	private Double price;
	private String image;
	private Date date;
	
    private Connection connect;
    private PreparedStatement prepare;
    private ResultSet result;
    
	
	public menuItem(Integer foodItemID, String itemName, String category, Double price, 
			String image, Date date) {
		this.foodItemID = foodItemID;
		this.itemName = itemName;
		this.category = category;
		this.price = price;
		this.image = image;
		this.date = date;
	}
	
	public Integer getFoodItemID() {
		/* String ID = "SELECT foodItemID FROM menu";
    	
    	connect = database.connectDB();
    	
		try {
			prepare = connect.prepareStatement(ID);
			result = prepare.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    	foodItemID = Integer.valueOf(ID);
    	*/
		return foodItemID;
	}

	
	public String getItemName() {
		return itemName;
	}
	
	public String getCategory() {
		return category;
	}
	
	public Double getPrice() {
		return price;
	}
	
	public String getImage() {
		return image;
	}
	
	public Date getDate() {
		return date;
	}

}