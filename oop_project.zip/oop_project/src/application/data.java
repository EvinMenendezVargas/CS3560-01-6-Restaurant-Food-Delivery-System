package application;

public class data {
	// Path to 
	public static String path;
	public static String date;
	public static Integer id;
	public static Integer cID;
}