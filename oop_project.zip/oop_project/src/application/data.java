package application;

public class data {
	// Path to 
	public static String path;
	
}