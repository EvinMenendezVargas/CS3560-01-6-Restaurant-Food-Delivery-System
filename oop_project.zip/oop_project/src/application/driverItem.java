package application;

import java.sql.Date;

public class driverItem {
	

	private Integer driverId;
	private String driverLicense;
	private String driverName;
	private String carType;
	private String driverStatus;
	private Date date;
	

	
	public driverItem(Integer driverId, String driverLicense, String driverName, String carType, String driverStatus, 
			Date date) {
		this.driverId = driverId;
		this.driverLicense = driverLicense;
		this.driverName = driverName;
		this.carType = carType;
		this.driverStatus = driverStatus;
		this.date = date;
	}
	
	public Integer getdriverId() {
		return driverId;
	}
	
	public String getDriverName() {
		return driverName;
	}
	
	public String getDriverLicense() {
		return driverLicense;
	}
	
	public String getCarType() {
		return carType;
	}
	
	public String getDriverStatus() {
		return driverStatus;
	}
	
	public Date getDate() {
		return date;
	}

}