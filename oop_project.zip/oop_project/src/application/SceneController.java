package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.util.Duration;


public class SceneController {

	private Stage stage;
	
	private Scene scene;
	
	private Parent root;
	
	@FXML
    private Button si_loginBtn;

    @FXML
    private AnchorPane si_loginForm;

    @FXML
    private TextField si_password;

    @FXML
    private TextField si_username;

    @FXML
    private Button side_CreateBtn;
    
    @FXML
    private Button side_alreadyHave;

    @FXML
    private AnchorPane side_form;

    @FXML
    private TextField su_answer;

    @FXML
    private TextField su_password;

    @FXML
    private ComboBox<?> su_question;

    @FXML
    private Button su_signupBtn;

    @FXML
    private AnchorPane su_signupForm;

    @FXML
    private TextField su_username;
    
    private Connection connect;
    
    private PreparedStatement prepare;
    
    private ResultSet result;
	
	// Scene1Controller.fxml = Welcome screen
	// Scene2Controller.fxml = Main Menu scene
	
	public void goScene1(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Scene1Controller.fxml"));
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		
		scene = new Scene(root);
		
		stage.setScene(scene);
		
		stage.show();
		
	}
	
	public void goMainMenu(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Scene2Controller.fxml"));
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		
		scene = new Scene(root);
		
		stage.setScene(scene);
		
		stage.show();
		
	}
	
	public void goAdminLogin(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("AdminLoginScene.fxml"));
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		
		scene = new Scene(root);
		
		stage.setScene(scene);
		
		stage.show();
		
	}
	
	
	public void goDeliveryStatus(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("DeliveryStatusScene.fxml"));
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		
		scene = new Scene(root);
		
		stage.setScene(scene);
		
		stage.show();
		
	}
	
	public void goMenuScreen(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("menuScreen.fxml"));
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		
		scene = new Scene(root);
		
		stage.setScene(scene);
		
		stage.show();
		
	}
	
	public void goCheckoutPayment(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("CheckoutPaymentScreen.fxml"));
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		
		scene = new Scene(root);
		
		stage.setScene(scene);
		
		stage.show();
		
	}


	// Switches from Login to Account Creation sides
    public void switchForm(ActionEvent event) {
    	
    	TranslateTransition slider = new TranslateTransition();
    	
    	if (event.getSource() == side_CreateBtn) {
    		
    		slider.setNode(side_form);
    		slider.setToX(300);
    		slider.setDuration(Duration.seconds(0.5));
    		
    		slider.setOnFinished((ActionEvent e) -> {
    			side_alreadyHave.setVisible(true);
    			side_CreateBtn.setVisible(false);
    		});
    		
    		slider.play();
    		
    	} else if (event.getSource() == side_alreadyHave) {
    		
    		slider.setNode(side_form);
    		slider.setToX(0);
    		slider.setDuration(Duration.seconds(0.5));
    		
    		slider.setOnFinished((ActionEvent e) -> {
    			side_alreadyHave.setVisible(false);
    			side_CreateBtn.setVisible(true);
    		});
    		
    		slider.play();
    		
    	}
    }
}
