package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.util.Duration;


public class SceneController {

	private Stage stage;
	
	private Scene scene;
	
	private Parent root;
	
	@FXML
    private Button si_loginBtn;

    @FXML
    private AnchorPane si_loginForm;

    @FXML
    private TextField si_password;

    @FXML
    private TextField si_username;

    @FXML
    private Button side_CreateBtn;
    
    @FXML
    private Button side_alreadyHave;

    @FXML
    private AnchorPane side_form;
    
    @FXML
    private TextField su_password;

    @FXML
    private DatePicker su_dob;

    @FXML
    private TextField su_email;

    @FXML
    private Button su_signupBtn;

    @FXML
    private AnchorPane su_signupForm;

    @FXML
    private TextField su_username;
    
    @FXML
    private Label deliveryStatusLabel;
    
    @FXML
    private Button driverAddBtn;

    @FXML
    private TextField driverDeliveryStatus_txtbox;

    @FXML
    private TextField driverName_txtbox;

    @FXML
    private TextField driverOrderNum_txtbox;

    @FXML
    private TextField driverPhoneNum_txtbox;
    
    private Connection connect;
    
    private PreparedStatement prepare;
    
    private ResultSet result;
    
    private Alert alert; 
	
	// Scene1Controller.fxml = Welcome screen
	// Scene2Controller.fxml = Main Menu scene
	
    public void loginBtn() throws IOException {
    	
    	// If username or password is empty, error message appears
    	if(si_username.getText().isEmpty() || si_password.getText().isEmpty()) {
    		
    		alert = new Alert(AlertType.ERROR);
    		alert.setTitle("Error Message");
    		alert.setHeaderText(null);
    		alert.setContentText("Please fill all the fields");
    		alert.showAndWait();
    		
    	} else {
    		
    		String selectData = "SELECT customer_username, customer_password FROM customer WHERE customer_username = ? and customer_password = ?";
    		connect = database.connectDB();
    		
    		try {
    			
    			prepare = connect.prepareStatement(selectData);
    			prepare.setString(1, si_username.getText());
    			prepare.setString(2, si_password.getText());
    			
    			result = prepare.executeQuery();
    			
    			// If successfully logged in, successful message will appear then proceed to next scene
    			if (result.next()) {
    				
    				
    				
    				alert = new Alert(AlertType.INFORMATION);
    				alert.setTitle("Information Message");
    				alert.setHeaderText(null);
    				alert.setContentText("Successful Login!");
    				alert.showAndWait();
    				
    				stage = new Stage();
    		    	
    		    	switch(si_username.getText().toString()) {
    		    	
    				case "admin":
    					root = FXMLLoader.load(getClass().getResource("AdminPortal.fxml"));
    					
    					scene = new Scene(root);
    					
    					stage.setTitle("Restaurant Food Delivery System");
    					stage.setWidth(1120);
    					stage.setHeight(650);
    					
    					stage.setScene(scene);
    					stage.show();
    					
    					si_loginBtn.getScene().getWindow().hide();
    					
    					break;
    					
    				case "driver":
    					root = FXMLLoader.load(getClass().getResource("DriverPortal.fxml"));
    					
    					scene = new Scene(root);
    					
    					stage.setTitle("Restaurant Food Delivery System");
    					stage.setWidth(1120);
    					stage.setHeight(650);
    					
    					
    					stage.setScene(scene);
    					stage.show();
    					
    					si_loginBtn.getScene().getWindow().hide();
    					
    					break;
    					
    				default:
    					root = FXMLLoader.load(getClass().getResource("Scene2Controller.fxml"));
    					
    					scene = new Scene(root);
    					
    					stage.setTitle("Restaurant Food Delivery System");
    					stage.setWidth(1120);
    					stage.setHeight(650);
    					
    					
    					stage.setScene(scene);
    					stage.show();
    					
    					si_loginBtn.getScene().getWindow().hide();
    		    	}
    				
    			// Else an error message will appear	
    			} else {
    				alert = new Alert(AlertType.ERROR);
    				alert.setTitle("Error Message");
    				alert.setHeaderText(null);
    				alert.setContentText("Incorrect Username/Password");
    				alert.showAndWait();
    				
    			}
    			
    		} catch (Exception e) {e.printStackTrace();}
    	
    	}
    	
    	
    	
    }
    
    /**
     * If any text field is left empty to register an account, show an alert. 
     * Else, update customer table with information and connect to database, 
     * then show success alert and clear entered information.
     * @param
     * @return
     */
    
	public void regBtn() {
		
		if (su_username.getText().isEmpty() || su_password.getText().isEmpty()
				|| su_email.getText().isEmpty() || su_dob.getValue() == null) {
			alert = new Alert(AlertType.ERROR);
			alert.setTitle("Error Message");
			alert.setHeaderText(null);
			alert.setContentText("Please fill all blank fields");
			alert.showAndWait();
			
		} else {
			// Store into database values 
			String regData = "INSERT INTO customer (customer_username, customer_password, customer_email, customer_dob, date) "
					+ "VALUES(?,?,?,?,?)";
			connect = database.connectDB();
			
			try {
				
				String checkUsername = "SELECT customer_username FROM customer WHERE customer_username = '"
						+ su_username.getText() + "'";
				
				prepare = connect.prepareStatement(checkUsername);
				result = prepare.executeQuery();
				
				// Check if the username is already recorded
				if(result.next()) {
					
					alert = new Alert(AlertType.ERROR);
					alert.setTitle("Error Message");
					alert.setHeaderText(null);
					alert.setContentText(su_username.getText() + " is already taken");
					alert.showAndWait();
				
				// Check if password is long enough
				} else if(su_password.getText().length() < 8) {
					
					alert = new Alert(AlertType.ERROR);
					alert.setTitle("Error Message");
					alert.setHeaderText(null);
					alert.setContentText("Invalid Password, atleast 8 characters are needed");
					alert.showAndWait();
					
					
				
				} else { 
					
				// Success: Add information to data base
				// int corresponds to a value in regData
				prepare = connect.prepareStatement(regData);
				prepare.setString(1, su_username.getText());
				prepare.setString(2, su_password.getText());
				prepare.setString(3, su_email.getText());
				prepare.setString(4, su_dob.getValue().toString());
				
				Date date = new Date();
				java.sql.Date sqlDate = new java.sql.Date(date.getTime());
				prepare.setString(5, String.valueOf(sqlDate));
				prepare.executeUpdate();
				
				alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Information Message");
				alert.setHeaderText(null);
				alert.setContentText("Successfully registered Account!");
				alert.showAndWait();
				
				su_username.setText("");
				su_password.setText("");
				su_email.setText("");
				su_dob.getEditor().clear();
				
				TranslateTransition slider = new TranslateTransition();
				
				slider.setNode(side_form);
	    		slider.setToX(0);
	    		slider.setDuration(Duration.seconds(0.5));
	    		
	    		slider.setOnFinished((ActionEvent e) -> {
	    			side_alreadyHave.setVisible(false);
	    			side_CreateBtn.setVisible(true);
	    		});
	    		
	    		slider.play();
	    		
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				}
		}
	}
	
	
	public void driverAdd_btn() {
		
			if(driverName_txtbox.getText().isEmpty() || driverOrderNum_txtbox.getText().isEmpty()
					|| driverName_txtbox.getText().isEmpty() || driverDeliveryStatus_txtbox.getText().isEmpty()
					|| driverPhoneNum_txtbox.getText().isEmpty()) {
    		
    		alert = new Alert(AlertType.ERROR);
    		alert.setTitle("Error Message");
    		alert.setHeaderText(null);
    		alert.setContentText("Please fill all the fields");
    		alert.showAndWait();
    		
			} else {
				
				String addData = "INSERT INTO driver (driver_name, driver_phone_num, order_confirmation, delivery_update_status) "
						+ "VALUES(?,?,?,?)";
				connect = database.connectDB();
				
				try {
					
					prepare = connect.prepareStatement(addData);
					prepare.setString(1, driverName_txtbox.getText());
					prepare.setString(2, driverPhoneNum_txtbox.getText());
					prepare.setString(3, driverPhoneNum_txtbox.getText());
					prepare.setString(4, su_dob.getValue().toString());
					
				} catch (Exception e){
					e.printStackTrace();
				}
			}
	}
	
	public void goMainMenu(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Scene2Controller.fxml"));
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		
		scene = new Scene(root);
		
		stage.setScene(scene);
		
		stage.show();
		
	}
	
	public void goLogout(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Scene1Controller.fxml"));
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		
		stage.setWidth(600);
		stage.setHeight(430);
		
		scene = new Scene(root);
		
		stage.setScene(scene);
		
		stage.show();
		
	}
	
	public void goDeliveryStatus(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("DeliveryStatusScene.fxml"));
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		
		scene = new Scene(root);
		
		stage.setScene(scene);
		
		stage.show();
		
	}
	
	public void goMenuScreen(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("menuScreen.fxml"));
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		
		scene = new Scene(root);
		
		stage.setScene(scene);
		
		stage.show();
		
	}
	
	public void goCheckoutPayment(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("CheckoutPaymentScreen.fxml"));
		
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		
		scene = new Scene(root);
		
		stage.setScene(scene);
		
		stage.show();
		
	}


	/**
	 * When Create button is pressed, side panel transitions.
	 * @param event
	 */
    public void switchForm(ActionEvent event) {
    	
    	TranslateTransition slider = new TranslateTransition();
    	
    	if (event.getSource() == side_CreateBtn) {
    		
    		slider.setNode(side_form);
    		slider.setToX(300);
    		slider.setDuration(Duration.seconds(0.5));
    		
    		slider.setOnFinished((ActionEvent e) -> {
    			side_alreadyHave.setVisible(true);
    			side_CreateBtn.setVisible(false);
    		});
    		
    		slider.play();
    		
    	} else if (event.getSource() == side_alreadyHave) {
    		
    		slider.setNode(side_form);
    		slider.setToX(0);
    		slider.setDuration(Duration.seconds(0.5));
    		
    		slider.setOnFinished((ActionEvent e) -> {
    			side_alreadyHave.setVisible(false);
    			side_CreateBtn.setVisible(true);
    		});
    		
    		slider.play();
    		
    	}
    }
}
