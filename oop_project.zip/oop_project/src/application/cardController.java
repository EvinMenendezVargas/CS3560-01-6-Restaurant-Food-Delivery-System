package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;


public class cardController implements Initializable {
	
	@FXML
    private Button add_btn;

    @FXML
    private AnchorPane card_form;

    @FXML
    private Label itemName;

    @FXML
    private ImageView item_imageView;

    @FXML
    private Label price;

    @FXML
    private Spinner<?> spinner;
    
    private menuItem menuItem;
    
    private Image image;
    
    public void setData(menuItem menuItem) {
    	this.menuItem = menuItem;
    	
    	itemName.setText(menuItem.getItemName());
    	price.setText(String.valueOf(menuItem.getPrice()));
    	String path = "File: " + menuItem.getImage();
    	image = new Image(menuItem.getImage(), 200, 113, false, true);
    	item_imageView.setImage(image);
    }
   
	
	public void initialize(URL location, ResourceBundle resources) {
		
	}
}