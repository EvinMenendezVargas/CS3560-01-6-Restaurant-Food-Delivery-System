package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;


public class cardController implements Initializable {
	
	@FXML
    private Button add_btn;
	
	private SpinnerValueFactory<Integer> spin;

    @FXML
    private AnchorPane card_form;

    @FXML
    private Label itemName;

    @FXML
    private ImageView item_imageView;

    @FXML
    private Label price;

    @FXML
    private Spinner<Integer> spinner;
    
    private menuItem menuItem;
    
    private Image image;
    
    private int qty;
    
    private Connection connect;
    
    private PreparedStatement prepare;
    
    private ResultSet result;
    
    private Alert alert;
    
    public void setData(menuItem menuItem) {
    	this.menuItem = menuItem;
    	
    	itemName.setText(menuItem.getItemName());
    	price.setText(String.valueOf(menuItem.getPrice()));
    	String path = "File: " + menuItem.getImage();
    	image = new Image(menuItem.getImage(), 200, 113, false, true);
    	item_imageView.setImage(image);
    }
   
    public void setQuantity() {
    	spin = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100, 0);
    	spinner.setValueFactory(spin);
    }
    
    public void add_btn() {
    	qty = spinner.getValue();
    	
    	if (qty == 0) {
    		alert = new Alert(AlertType.ERROR);
    		alert.setTitle("Error Message");
    		alert.setHeaderText(null);
    		alert.setContentText("");
    	} else {
    		String insertData = "INSERT INTO order " + "(foodItemID, itemName, category, quantity, price, date)";
    		try {
    			
    		} catch (Exception e) {e.printStackTrace();}
    	}
    }
	
	public void initialize(URL location, ResourceBundle resources) {
		
	}
}